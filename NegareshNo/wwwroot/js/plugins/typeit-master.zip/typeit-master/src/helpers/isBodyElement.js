export default node => {
  return node.tagName === "BODY";
};
