export default thing => {
  return Array.isArray(thing);
};
