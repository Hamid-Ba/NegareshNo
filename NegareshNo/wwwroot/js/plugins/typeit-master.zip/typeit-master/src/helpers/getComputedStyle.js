export default el => {
  return window.getComputedStyle(el, null);
};
