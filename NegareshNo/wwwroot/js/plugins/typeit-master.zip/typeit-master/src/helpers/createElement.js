export default el => {
  return document.createElement(el);
};
