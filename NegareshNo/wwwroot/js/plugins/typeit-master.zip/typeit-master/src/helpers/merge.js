export default (originalObj, newObj) => {
  return Object.assign({}, originalObj, newObj);
};
