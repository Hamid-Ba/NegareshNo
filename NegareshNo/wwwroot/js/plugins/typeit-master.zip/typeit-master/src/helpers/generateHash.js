export default () => {
  return Math.random()
    .toString()
    .substring(2, 9);
};
